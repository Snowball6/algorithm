# Time series analysis with ARIMA
Simple python example on how to use ARIMA models to analyze and predict time series.
